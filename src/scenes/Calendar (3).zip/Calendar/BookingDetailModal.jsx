import React from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";
import "./BookingDetailModal.css"; // Custom CSS for styling

const BookingDetailModal = ({ booking, show, onClose, refreshBookings }) => {
  if (!booking) return null;

  // Formatting Date and Time for display
  const formatDate = (date) => new Date(date).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  const formatTime = (start, end) => `${new Date(start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${new Date(end).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

  // Map actual status to display names
  const getDisplayStatus = (status) => {
    switch (status) {
      case "BOOKED":
        return "Pending";
      case "COMPLETED":
        return "Completed";
      case "CANCELLED":
        return "Cancelled";
      case "OFFER_ACCEPTED":
        return "Cancellation offer accepted";
      case "NOSHOW":
        return "Absence from booking";
      case "OFFERED":
        return "Awaiting new customer";
      default:
        return status;
    }
  };

  // API URL and Authorization
  const apiUrl = process.env.REACT_APP_URL;
  const authTokenUser = localStorage.getItem("auth_token");

  const updateBookingStatus = async (status) => {
    if (!booking.id) {
      console.error("Booking ID is missing"); // Check for missing ID
      return;
    }

    const payload = { id: booking.id };
    let endpoint = "";

    switch (status) {
      case "COMPLETED":
        endpoint = `${apiUrl}/api/v1/store/booking/complete`;
        break;
      case "CANCELLED":
        endpoint = `${apiUrl}/api/v1/store/booking/cancel`;
        break;
      case "BOOKED":
        endpoint = `${apiUrl}/api/v1/store/booking/pending`;
        break;
      case "NOSHOW":
        endpoint = `${apiUrl}/api/v1/store/booking/noshow`;
        break;
      case "DELETED":
        endpoint = `${apiUrl}/api/v1/store/booking/delete`;
        break;
      case "RESCHEDULED":
        endpoint = `${apiUrl}/api/v1/store/booking/reschedule`;
        payload.booking_date = formatDate(booking.date);
        payload.time_slot = `${formatTime(booking.startTime, booking.endTime)}`;
        payload.employee_id = booking.employeeId;
        payload.total_amount = booking.price;
        break;
      default:
        return;
    }

    try {
      const response = await axios.post(endpoint, payload, {
        headers: {
          Authorization: `Bearer ${authTokenUser}`,
        },
      });
      if (response.data.success) {
        alert("Booking status updated successfully");
        onClose();
        refreshBookings(); // Refresh bookings in the calendar view
      } else {
        alert("Failed to update booking status");
      }
    } catch (error) {
      console.error("Error updating booking status:", error);
    }
  };

  // Button handlers
  const handleMarkAsCompleted = () => updateBookingStatus("COMPLETED");
  const handleCancelBooking = () => updateBookingStatus("CANCELLED");
  const handleMarkAsPending = () => updateBookingStatus("BOOKED");
  const handleAbsenceFromBooking = () => updateBookingStatus("NOSHOW");
  const handleDeleteBooking = () => updateBookingStatus("DELETED");
  const handleRescheduleBooking = () => updateBookingStatus("RESCHEDULED");

  // Render buttons based on status
  const renderActionButtons = () => {
    switch (booking.status) {
      case "BOOKED":
        return (
          <>
            <button className="modal-button" onClick={handleMarkAsCompleted}>Mark as completed</button>
            <button className="modal-button" onClick={handleCancelBooking}>Cancel booking</button>
            <button className="modal-button" onClick={handleRescheduleBooking}>Reschedule booking</button>
            <button className="modal-button" onClick={handleAbsenceFromBooking}>Absence from booking</button>
            <button className="modal-button" onClick={handleDeleteBooking}>Delete booking</button>
          </>
        );
      case "CANCELLED":
        return (
          <>
            <button className="modal-button" onClick={handleMarkAsPending}>Mark as pending</button>
            <button className="modal-button" onClick={handleRescheduleBooking}>Reschedule booking</button>
            <button className="modal-button" onClick={handleDeleteBooking}>Delete booking</button>
          </>
        );
      case "COMPLETED":
        return (
          <>
            <button className="modal-button" onClick={handleMarkAsPending}>Mark as pending</button>
            <button className="modal-button" onClick={handleCancelBooking}>Cancel booking</button>
            <button className="modal-button" onClick={handleRescheduleBooking}>Reschedule booking</button>
            <button className="modal-button" onClick={handleAbsenceFromBooking}>Absence from booking</button>
            <button className="modal-button" onClick={handleDeleteBooking}>Delete booking</button>
          </>
        );
      case "NOSHOW":
        return (
          <>
            <button className="modal-button" onClick={handleMarkAsPending}>Mark as pending</button>
            <button className="modal-button" onClick={handleMarkAsCompleted}>Mark as completed</button>
            <button className="modal-button" onClick={handleCancelBooking}>Cancel booking</button>
            <button className="modal-button" onClick={handleRescheduleBooking}>Reschedule booking</button>
            <button className="modal-button" onClick={handleDeleteBooking}>Delete booking</button>
          </>
        );
      case "OFFER_ACCEPTED":
        return (
          <>
            <button className="modal-button" onClick={handleMarkAsCompleted}>Mark as completed</button>
            <button className="modal-button" onClick={handleAbsenceFromBooking}>Absence from booking</button>
          </>
        );
      case "OFFERED":
        return (
          <>
            <button className="modal-button" onClick={handleCancelBooking}>Cancel booking</button>
            <button className="modal-button" onClick={handleDeleteBooking}>Delete booking</button>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <Modal show={show} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Booking Details</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="details">
          <p><strong>Name:</strong> {booking.name || "N/A"}</p>
          <p><strong>Phone nr.:</strong> {booking.phone || "N/A"}</p>
          <p><strong>Employee:</strong> {booking.employee || "N/A"}</p>
          <p><strong>Service:</strong> {booking.service || "N/A"}</p>
          <p><strong>Date:</strong> {formatDate(booking.date)}</p>
          <p><strong>Time:</strong> {formatTime(booking.startTime, booking.endTime)}</p>
          <p><strong>Status:</strong> <span className={`status ${booking.status.toLowerCase()}`}>{getDisplayStatus(booking.status)}</span></p>
          <p><strong>Created:</strong> {formatDate(booking.created)}</p>
          <p style={{ border: 'none' }}><strong>Price:</strong> ${booking.price}</p>

        </div>

        {/* Render the action buttons based on the booking status */}
        <div className="action-buttons">
          {renderActionButtons()}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
};

export default BookingDetailModal;
